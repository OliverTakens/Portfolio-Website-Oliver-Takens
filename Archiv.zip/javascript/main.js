"use strict"

document.addEventListener("DOMContentLoaded", () => {
    const jobPositions = document.getElementsByClassName("about__position")

    for(const jobPosition of jobPositions){
        jobPosition.addEventListener("click", () => {
            jobPosition.classList.toggle("no__border")
            const cardBody = jobPosition.nextElementSibling
            cardBody.classList.toggle("display__none")


            const cardIcon = jobPosition.querySelector(".about__icon")
            cardIcon.classList.toggle("rotate90deg")
        })
    }

    const skillBoxes = document.getElementsByClassName("skill__box");

    for (const skillBox of skillBoxes) {
        skillBox.addEventListener("mouseover", () => {
            for (const otherBox of skillBoxes) {
                if (otherBox !== skillBox) {
                    otherBox.classList.add("dimmed");
                }
            }
        });

        skillBox.addEventListener("mouseout", () => {
            for (const otherBox of skillBoxes) {
                otherBox.classList.remove("dimmed");
            }
        });
    }


    // Slider
    const slider1 = document.getElementById("slider1");
    const images1 = [
        "webshop1.webp",
        "webshop2.webp",
        "webshop3.webp"
    ]
    const slider2 = document.getElementById("slider2");
    const images2 = [
        "webagency1.webp",
        "webagency2.webp",
        "webagency3.webp"
    ]
    const slider3 = document.getElementById("slider3");
    const images3 = [
        "doctor1.webp",
        "doctor2.webp",
        "doctor3.webp"
    ]
    let id1 = 0;
    const arrLeft1 = document.querySelector(".arrow__left1");
    const arrRight1 = document.querySelector(".arrow__right1");
    let id2 = 0;
    const arrLeft2 = document.querySelector(".arrow__left2");
    const arrRight2 = document.querySelector(".arrow__right2");
    let id3 = 0;
    const arrLeft3 = document.querySelector(".arrow__left3");
    const arrRight3 = document.querySelector(".arrow__right3");

    function slide(id1) {
        slider1.style.backgroundImage = `url(../images/${images1[id1]})`; 
    }
    function slide2(id2) {
        slider2.style.backgroundImage = `url(../images/${images2[id2]})`; 
    }
    function slide3(id3) {
        slider3.style.backgroundImage = `url(../images/${images3[id3]})`; 
    }

    arrLeft1.addEventListener("click", () => {
        id1--;
        if(id1 < 0){
            id1 = images1.length - 1
        }
        slide(id1)
    })

    arrRight1.addEventListener("click", () => {
        id1++;
        if(id1 > images1.length - 1){
            id1 = 0
        }
        slide(id1)
    })

    arrLeft2.addEventListener("click", () => {
        id2--;
        if(id2 < 0){
            id2 = images2.length - 1
        }
        slide2(id2)
    })

    arrRight2.addEventListener("click", () => {
        id2++;
        if(id2 > images2.length - 1){
            id2 = 0
        }
        slide2(id2)
    })

    arrLeft3.addEventListener("click", () => {
        id3--;
        if(id3 < 0){
            id3 = images3.length - 1
        }
        slide3(id3)
    })

    arrRight3.addEventListener("click", () => {
        id3++;
        if(id3 > images3.length - 1){
            id3 = 0
        }
        slide3(id3)
    })
  }) 